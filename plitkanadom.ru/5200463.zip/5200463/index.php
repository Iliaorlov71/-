
<?if (isset($_GET["login"])){

  require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php");?>
  <h>Список страниц каталога</h>
  <span>Плитка</span>
  <br>
  <a href="https://www.plitkanadom.ru/5200463/keramplitka/">Разделы </a>  <br>
  <a href="https://www.plitkanadom.ru/5200463/keramplitka/tovar.php">Товары</a>    <br>
  <span>Напольные покрытия</span>                                          <br>
  <a href="https://www.plitkanadom.ru/5200463/napolnye/">Разделы</a>    <br>
  <a href="https://www.plitkanadom.ru/5200463/napolnye/tovar.php">Товары</a>  <br>
  <span>Сантехника</span>                                                       <br>
  <a href="https://www.plitkanadom.ru/5200463/santeh/">Разделы</a>        <br>
  <a href="https://www.plitkanadom.ru/5200463/santeh/tovar.php">Товары</a>   <br>
  <span>Смеси</span>                                                      <br>
  <a href="https://www.plitkanadom.ru/5200463/smesi/">Разделы</a>         <br>
  <a href="https://www.plitkanadom.ru/5200463/smesi/tovar.php">Товары</a><br>

  <?
}else{die();}?>
